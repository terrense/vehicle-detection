import sys
sys.path.append("/usr/src/app/")
from ultralytics import YOLO
import math
import cv2
import os
import numpy as np

# # 以下PIL库在提交的时候要注释掉
# from PIL import Image

def non_max_suppression(detections, threshold=0.2):
    # 如果没有检测结果，直接返回空列表
    if len(detections) == 0:
        return []

    # 按照置信度对检测结果排序（从高到低）
    detections.sort(key=lambda x: x[5], reverse=True)

    # 初始化一个列表来存储最终的非极大值抑制结果
    nms_results = []

    while len(detections) > 0:
        # 选择置信度最高的检测结果
        best_detection = detections.pop(0)
        nms_results.append(best_detection)

        # 计算当前检测结果与其余检测结果的重叠程度（IoU）
        best_xmin, best_xmax, best_ymin, best_ymax = best_detection[1:5] #第二到第五个元素， 4个， xmin, xmax, ymin, ymax

        iou_filtered_detections = []
        for detection in detections:
            xmin, xmax, ymin, ymax = detection[1:5]

            x_left = max(best_xmin, xmin)
            y_top = max(best_ymin, ymin)
            x_right = min(best_xmax, xmax)
            y_bottom = min(best_ymax, ymax)

            if x_left < x_right and y_top < y_bottom:
                intersection_area = max(0, x_right - x_left) * max(0, y_bottom - y_top)
                best_area = (best_xmax - best_xmin) * (best_ymax - best_ymin)
                detection_area = (xmax - xmin) * (ymax - ymin)
                iou = intersection_area / (best_area + detection_area - intersection_area)
                k1 = intersection_area / best_area
                k2 = intersection_area / detection_area

                if k1 < 0.9 and k2 < 0.9:
                    if iou <= threshold:
                        iou_filtered_detections.append(detection)
            else: iou_filtered_detections.append(detection)

        # 更新detections列表以继续进行NMS
        detections = iou_filtered_detections

    return nms_results

def sliding_window(imshape, patchsize, overlap_ratio=0.2):
    # Get the width and height of the image
    # height, width, channels = image.shape
    stride_y = int(patchsize[0] * (1 - overlap_ratio))
    stride_x = int(patchsize[1] * (1 - overlap_ratio))
    yn = math.ceil((imshape[0]-patchsize[0]) / stride_y)+1
    xn = math.ceil((imshape[1]-patchsize[1]) / stride_x)+1
    pp = []
    for x in range(xn):
        for y in range(yn):
            px = x*stride_x
            py = y*stride_y
            if y == yn-1:
                py = imshape[0]-patchsize[0]
            if x == xn-1:
                px = imshape[1]-patchsize[1]
            pp.append((px, py))
            #width , height
    return pp

def save_to_txt(results, txt_file, save_conf=True):
    """
    Save predictions into txt file.

    Args:
        results (list): List of detection results to save.
        txt_file (str): txt file path.
        save_conf (bool): save confidence score or not.
    """
    texts = []

    for result in results:
        c, xmin, xmax, ymin, ymax, conf, *rest = result
        line = (c, xmin, xmax, ymin, ymax)
        line += (conf, ) * save_conf
        texts.append(('%g ' * len(line)).rstrip() % line)

    if texts:
        output_dir = os.path.dirname(txt_file)
        if not os.path.exists(output_dir):
            os.makedirs(output_dir)  # 创建目录

        with open(txt_file, 'a') as f:
            f.writelines(text + '\n' for text in texts)




if __name__ == "__main__":

    # Load a model 你训练的pt文件  针对VI
    model1 = YOLO('8x-p2.pt')
    # 设置图像文件夹路径
    
    # Define path to the image file
    source11 = '/data/input_data/VIData'
    image_files1 = [os.path.join(source11, filename) for filename in os.listdir(source11) if filename.endswith('.jpg')]
    source12 = '/data/input_data/IRData'
    image_files1 += [os.path.join(source12, filename) for filename in os.listdir(source12) if filename.endswith('.jpg')]
    
    
    # SAR图像的后缀名是tif
    # 用于存储读取的图像的列表
    image_list1 = []
    image_names1 = []
    # 循环读取图像并将它们添加到列表中
    for image_file1 in image_files1:
        base_image_name1 = os.path.splitext(os.path.basename(image_file1))[0]
        image1 = cv2.imread(image_file1)
        if image1 is not None:
            image_list1.append(image1)
            image_names1.append(base_image_name1)
    print('image_names:', image_names1)
    
    # 用于存储生成的输出文件名的列表
    output_file_names = []
    input_folder=source11
    # 遍历输入文件夹中的图片文件
    for filename in os.listdir(input_folder):
        if filename.endswith('.jpg') and filename.startswith('vi_'):
            # 提取帧号和航线号
            parts = filename.split('_')  # 拆分文件名
            frame_number = parts[1]  # 第二部分是帧号
            airline_number = parts[2].split('.')[0]  # 第三部分去掉扩展名是航线号

            # 构建结果文件名
            result_filename = f"{frame_number}_{airline_number}"

            # 将生成的输出文件名添加到列表
            output_file_names.append(result_filename)


    

    # Load a model 你训练的pt文件  针对SAR
    model2 = YOLO('SAR.pt')
    #input path for SAR
    image_folder2 = '/data/input_data/SAR'
    # 列出文件夹内的所有图像文件
    image_files2 = [os.path.join(image_folder2, filename) for filename in os.listdir(image_folder2) if
                   filename.endswith(('.tif'))]
    #SAR图像的后缀名是tif
    # 用于存储读取的图像的列表
    image_list2 = []
    image_names2 = []
    # 循环读取图像并将它们添加到列表中
    for image_file2 in image_files2:
        base_image_name2 = os.path.splitext(os.path.basename(image_file2))[0]
        image2 = cv2.imread(image_file2)
        if image2 is not None:
            image_list2.append(image2)
            image_names2.append(base_image_name2)
    print('image_names:',image_names2)


    imgsz = (1024,1024)

    for im, name in zip(image_list2, image_names2):

        output_path = f"/data/result/SAR/{name}.txt"
        image_size = (im.shape[0], im.shape[1]) #im.shape[0] 通常表示图像的高度（height），而 im.shape[1] 表示图像的宽度（width）。
        # 这是因为通常情况下，图像的形状通常以 (height, width) 的顺序来表示
        pp = sliding_window((im.shape[0], im.shape[1]), imgsz)
        pred_r = []
        imgs = []
        output_informations = []
        i = 0  # i在提交的时候要注释掉
        for pxy in pp:
            delta_x = pxy[1] #width
            delta_y = pxy[0] #height
            t_img = im[pxy[0]:pxy[0] + imgsz[0], pxy[1]:pxy[1] + imgsz[1], :]
            imgs.append(t_img)
            results = model2.predict(t_img, conf=0.25)

            i = i + 1

            for result in results:
                #查看测试结果
                # # 以下三行在提交的时候要注释掉
                # im_array = result.plot()  # plot a BGR numpy array of predictions
                # im1024 = Image.fromarray(im_array[..., ::-1])  # RGB PIL image
                # im1024.save(f"/data/result/SAR/{i}.jpg")

                coordinates = np.array(result.boxes.xxyy.cpu())
                conff = result.boxes.conf
                # print('conff:',conff)
                for coordinate, conf in zip(coordinates, conff):
                    xmin = coordinate[0] + delta_x
                    xmax = coordinate[1] + delta_x
                    ymin = coordinate[2] + delta_y
                    ymax = coordinate[3] + delta_y
                    conf = np.array(conf.cpu()).tolist()
                    # print('conf:', conf)
                    output_line = (0, xmin, xmax, ymin, ymax, float('%.4f' % conf)) #满足输出要求的坐标值
                    # print('output_line:',output_line)
                    output_informations.append(output_line)

        nms_results = non_max_suppression(output_informations)

        save_to_txt(nms_results, output_path)


    for im1, name1 in zip(image_list1, output_file_names):
        output_path1 = f"/data/result/VI_IR/{name1}.txt"
        output_informations1 =[]
        # Run inference on the source
        results_VI = model1.predict(im1, save_txt=True, save_conf=True, conf=0.2)

        for result1 in results_VI:
            # image_array=result1.plot()
            # imageVI = Image.fromarray(image_array[..., ::-1])
            # imageVI.save(f"/data/result/VI_IR/{name1}.jpg")

            coordis = np.array(result1.boxes.xxyy.cpu())
            confs = result1.boxes.conf
            clss = result1.boxes.cls
            for coordi, conf1, cls1 in zip(coordis, confs, clss):
                xmin1 = coordi[0]
                xmax1 = coordi[1]
                ymin1 = coordi[2]
                ymax1 = coordi[3]
                conf1 = np.array(conf1.cpu()).tolist()
                cls1 = np.array(cls1.cpu()).tolist()
                output_line1 = (cls1, xmin1, xmax1, ymin1, ymax1, float('%.4f' % conf1))
                output_informations1.append(output_line1)

        save_to_txt(output_informations1, output_path1)